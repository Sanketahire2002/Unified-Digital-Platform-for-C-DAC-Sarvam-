package com.cdac.sarvam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SarvamApplication {

    public static void main(String[] args) {
        SpringApplication.run(SarvamApplication.class, args);
    }

}
