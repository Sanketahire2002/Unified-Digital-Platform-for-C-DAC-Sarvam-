package com.cdac.sarvam.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CCATDTO {
    private String message;
    private Object data;
}
