package com.cdac.sarvam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SarvamApplicationTests {

	@Test
	void contextLoads() {
	}

}
