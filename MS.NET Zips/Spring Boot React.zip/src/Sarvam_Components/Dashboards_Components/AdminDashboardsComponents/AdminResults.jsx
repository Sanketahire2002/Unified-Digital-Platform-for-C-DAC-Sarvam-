  
// AdminResults.jsx
import React from 'react';

const AdminResults = () => {
  return (
    <div className="admin-results">
      <h1>Results</h1>
      <p>This section is for viewing results.</p>
    </div>
  );
};

export default AdminResults;
