  
// AdminStaff.jsx
import React from 'react';

const AdminStaff = () => {
  return (
    <div className="admin-staff">
      <h1>Staff</h1>
      <p>This section is for managing staff members.</p>
    </div>
  );
};

export default AdminStaff;
