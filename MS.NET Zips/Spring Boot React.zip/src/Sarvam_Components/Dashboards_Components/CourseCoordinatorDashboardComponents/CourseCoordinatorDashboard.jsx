
import React from 'react';

function CourseCoordinatorDashboard() {
  return (
    <div>
      <h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1><h1>Course Coordinator Dashboards</h1>
    </div>
  );
}

export default CourseCoordinatorDashboard;
