
import React from 'react';

function CourseCoordinatorProfile() {
  return (
    <div>
      <h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1><h1>Course Coordinator Profile</h1>
    </div>
  );
}

export default CourseCoordinatorProfile;
