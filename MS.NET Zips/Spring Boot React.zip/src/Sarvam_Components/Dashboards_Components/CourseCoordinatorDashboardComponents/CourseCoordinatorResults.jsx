
import React from 'react';

function CourseCoordinatorResults() {
  return (
    <div>
      <h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1><h1>Course Coordinator Results</h1>
    </div>
  );
}

export default CourseCoordinatorResults;
