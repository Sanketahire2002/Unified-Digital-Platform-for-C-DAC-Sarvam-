
import React from 'react';

function CourseCoordinatorSecurity() {
  return (
    <div>
      <h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1><h1>Course Coordinator Security</h1>
    </div>
  );
}

export default CourseCoordinatorSecurity;
