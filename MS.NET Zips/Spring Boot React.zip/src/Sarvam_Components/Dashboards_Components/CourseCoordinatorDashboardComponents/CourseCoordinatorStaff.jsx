
import React from 'react';

function CourseCoordinatorStaff() {
  return (
    <div>
      <h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1><h1>Course Coordinator Staff</h1>
    </div>
  );
}

export default CourseCoordinatorStaff;
