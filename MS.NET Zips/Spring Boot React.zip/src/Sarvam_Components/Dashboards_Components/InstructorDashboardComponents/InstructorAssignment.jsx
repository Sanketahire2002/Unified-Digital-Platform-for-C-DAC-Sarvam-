import React from 'react';

function InstructorAssignment() {
  return (
    <div>
      <h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1><h1>Instructor  Assignment</h1>
    </div>
  );
}

export default InstructorAssignment;
