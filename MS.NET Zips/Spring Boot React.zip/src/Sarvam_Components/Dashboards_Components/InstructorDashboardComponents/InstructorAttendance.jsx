
import React from 'react';

function InstructorAttendance() {
  return (
    <div>
      <h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1><h1>Instructor  Attendance</h1>
    </div>
  );
}

export default InstructorAttendance;
