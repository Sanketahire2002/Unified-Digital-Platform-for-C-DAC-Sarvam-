
import React from 'react';

function InstructorPlacements() {
  return (
    <div>
      <h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1><h1>Instructor  Placements</h1>
    </div>
  );
}

export default InstructorPlacements;
