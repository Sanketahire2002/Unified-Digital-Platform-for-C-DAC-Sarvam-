
import React from 'react';

function InstructorResults() {
  return (
    <div>
      <h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1><h1>Instructor  Results</h1>
    </div>
  );
}

export default InstructorResults;
