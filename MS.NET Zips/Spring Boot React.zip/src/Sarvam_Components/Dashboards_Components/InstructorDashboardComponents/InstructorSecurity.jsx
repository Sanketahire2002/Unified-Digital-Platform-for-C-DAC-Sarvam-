
import React from 'react';

function InstructorSecurity() {
  return (
    <div>
      <h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1><h1>Instructor  Security</h1>
    </div>
  );
}

export default InstructorSecurity;
