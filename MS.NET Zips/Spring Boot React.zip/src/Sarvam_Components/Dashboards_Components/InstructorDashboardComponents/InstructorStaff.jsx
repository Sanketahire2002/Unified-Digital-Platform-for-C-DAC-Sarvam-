
import React from 'react';

function InstructorStaff() {
  return (
    <div>
      <h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1><h1>Instructor  Staff</h1>
    </div>
  );
}

export default InstructorStaff;
