
import React from 'react';

function InstructorUsers() {
  return (
    <div>
      <h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1><h1>Instructor  Users</h1>
    </div>
  );
}

export default InstructorUsers;
