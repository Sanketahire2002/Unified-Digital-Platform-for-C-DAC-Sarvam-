
import React from 'react';

function ModuleCoordinatorDashboard() {
  return (
    <div>
      <h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1><h1>Module Coordinator Dashboards</h1>
    </div>
  );
}

export default ModuleCoordinatorDashboard;
