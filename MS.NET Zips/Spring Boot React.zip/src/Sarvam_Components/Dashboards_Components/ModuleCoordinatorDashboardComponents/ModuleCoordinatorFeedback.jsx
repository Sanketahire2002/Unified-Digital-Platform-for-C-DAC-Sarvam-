
import React from 'react';

function ModuleCoordinatorFeedback() {
  return (
    <div>
      <h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1><h1>Module Coordinator Feedback</h1>
    </div>
  );
}

export default ModuleCoordinatorFeedback;
