
import React from 'react';

function ModuleCoordinatorUsers() {
  return (
    <div>
      <h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1><h1>Module Coordinator Users</h1>
    </div>
  );
}

export default ModuleCoordinatorUsers;
