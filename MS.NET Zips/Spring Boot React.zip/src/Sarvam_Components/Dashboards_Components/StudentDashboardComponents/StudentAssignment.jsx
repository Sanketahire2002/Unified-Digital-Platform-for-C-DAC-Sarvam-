  
// AdminAssignment.jsx
import React from 'react';

const AdminAssignment = () => {
  return (
    <div className="admin-assignment">
      <h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1><h1>Assignment</h1>
      <p>This section is for managing assignments.</p>
    </div>
  );
};

export default AdminAssignment;
