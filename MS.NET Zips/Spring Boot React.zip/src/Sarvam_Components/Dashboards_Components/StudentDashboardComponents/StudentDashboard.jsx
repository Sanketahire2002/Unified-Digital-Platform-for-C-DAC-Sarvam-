  
// AdminDashboard.jsx
import React from 'react';

const AdminDashboard = () => {
  return (
    <div className="admin-dashboard">
      <h1>Welcome to the Student Dashboard</h1>
      <h1>Welcome to the Student Dashboard</h1>
      <h1>Welcome to the Student Dashboard</h1>
      <p>This is the main dashboard for the Student panel.1111</p>
    </div>
  );
};

export default AdminDashboard;
