﻿namespace Sarvam.DTO
{
    public class MasterModuleSubpointDTO
    {
        public int SubId { get; set; }
        public string ModuleSubpointName { get; set; }
        public int ModuleId { get; set; }  // Added this propert
    }
}
