﻿namespace Sarvam.Models
{
    public class AnswerModel
    {
        public int QuestionId { get; set; }
        public string SelectedAnswer { get; set; }
    }
}
