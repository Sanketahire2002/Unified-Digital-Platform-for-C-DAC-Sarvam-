﻿namespace Sarvam.Models
{
    public class QuizResult
    {
        public int ModuleId { get; set; }
        public int TotalQuestions { get; set; }
        public int CorrectAnswers { get; set; }
        public int TotalMarks { get; set; }
    }
}
