  
// AdminDashboard.jsx
import React from 'react';

const AdminDashboard = () => {
  return (
    <div className="admin-dashboard">
      <h1>Welcome to the Admin Dashboard</h1>
      <h1>This is the main dashboard for the admin panel.</h1>
    </div>
  );
};

export default AdminDashboard;
