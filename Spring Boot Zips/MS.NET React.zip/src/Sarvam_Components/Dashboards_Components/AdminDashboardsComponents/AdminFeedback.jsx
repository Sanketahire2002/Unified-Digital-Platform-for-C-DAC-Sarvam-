  
// AdminFeedback.jsx
import React from 'react';

const AdminFeedback = () => {
  return (
    <div className="admin-feedback">
      <h1>Feedback</h1>
      <p>This section is for managing feedback.</p>
    </div>
  );
};

export default AdminFeedback;
