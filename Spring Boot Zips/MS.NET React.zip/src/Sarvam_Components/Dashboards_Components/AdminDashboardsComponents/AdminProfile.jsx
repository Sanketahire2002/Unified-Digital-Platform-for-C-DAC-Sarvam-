 
// AdminUsers.jsx
import React from 'react';

const AdminProfile = () => {
  return (
    <div className="admin-profile">
      <h1>Admin Profile</h1>
      <p>This section is for managing Admin Profile.</p>
    </div>
  );
};

export default AdminProfile;
