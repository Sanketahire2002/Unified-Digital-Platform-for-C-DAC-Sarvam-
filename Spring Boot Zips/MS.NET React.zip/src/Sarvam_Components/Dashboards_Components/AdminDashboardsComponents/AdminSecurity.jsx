  
// AdminSecurity.jsx
import React from 'react';

const AdminSecurity = () => {
  return (
    <div className="admin-security">
      <h1>Security</h1>
      <p>This section is for security settings and reports.</p>
    </div>
  );
};

export default AdminSecurity;
