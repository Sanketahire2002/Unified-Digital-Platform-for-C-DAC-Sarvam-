import React from 'react';

function CourseCoordinatorAssignment() {
  return (
    <div>
      <h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1><h1>Course Coordinator Assignment</h1>
    </div>
  );
}

export default CourseCoordinatorAssignment;
