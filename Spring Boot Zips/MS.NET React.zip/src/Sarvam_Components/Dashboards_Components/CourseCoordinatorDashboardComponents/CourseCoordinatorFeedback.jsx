
import React from 'react';

function CourseCoordinatorFeedback() {
  return (
    <div>
      <h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1><h1>Course Coordinator Feedback</h1>
    </div>
  );
}

export default CourseCoordinatorFeedback;
