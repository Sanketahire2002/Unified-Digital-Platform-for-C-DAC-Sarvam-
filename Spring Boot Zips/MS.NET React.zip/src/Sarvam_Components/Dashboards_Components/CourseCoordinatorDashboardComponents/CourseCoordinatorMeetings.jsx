
import React from 'react';

function CourseCoordinatorMeetings() {
  return (
    <div>
      <h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1><h1>Course Coordinator Meetings</h1>
    </div>
  );
}

export default CourseCoordinatorMeetings;
