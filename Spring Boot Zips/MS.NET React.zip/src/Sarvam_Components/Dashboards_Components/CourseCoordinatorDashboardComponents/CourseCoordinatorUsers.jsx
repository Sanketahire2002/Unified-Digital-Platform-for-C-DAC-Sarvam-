
import React from 'react';

function CourseCoordinatorUsers() {
  return (
    <div>
      <h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1><h1>Course Coordinator Users</h1>
    </div>
  );
}

export default CourseCoordinatorUsers;
