
import React from 'react';

function InstructorDashboard() {
  return (
    <div>
      <h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1><h1>Instructor  Dashboards</h1>
    </div>
  );
}

export default InstructorDashboard;
