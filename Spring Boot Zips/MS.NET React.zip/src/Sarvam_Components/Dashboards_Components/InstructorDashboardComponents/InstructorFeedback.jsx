
import React from 'react';

function InstructorFeedback() {
  return (
    <div>
      <h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1><h1>Instructor  Feedback</h1>
    </div>
  );
}

export default InstructorFeedback;
