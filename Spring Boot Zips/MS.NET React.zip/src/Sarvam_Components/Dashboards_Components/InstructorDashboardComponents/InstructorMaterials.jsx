
import React from 'react';

function InstructorMaterials() {
  return (
    <div>
      <h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1><h1>Instructor  Materials</h1>
    </div>
  );
}

export default InstructorMaterials;
