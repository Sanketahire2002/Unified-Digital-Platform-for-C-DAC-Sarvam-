
import React from 'react';

function InstructorQuiz() {
  return (
    <div>
      <h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1><h1>Instructor  Quiz</h1>
    </div>
  );
}

export default InstructorQuiz;
