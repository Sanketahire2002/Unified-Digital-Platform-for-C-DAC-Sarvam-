
import React from 'react';

function InstructorSyllabus() {
  return (
    <div>
      <h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1><h1>Instructor  Syllabus</h1>
    </div>
  );
}

export default InstructorSyllabus;
