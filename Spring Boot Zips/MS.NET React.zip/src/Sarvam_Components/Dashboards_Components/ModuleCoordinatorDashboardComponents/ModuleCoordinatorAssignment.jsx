import React from 'react';

function ModuleCoordinatorAssignment() {
  return (
    <div>
      <h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1><h1>Module Coordinator Assignment</h1>
    </div>
  );
}

export default ModuleCoordinatorAssignment;
