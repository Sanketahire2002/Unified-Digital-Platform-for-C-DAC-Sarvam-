
import React from 'react';

function ModuleCoordinatorProfile() {
  return (
    <div>
      <h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1><h1>Module Coordinator Profile</h1>
    </div>
  );
}

export default ModuleCoordinatorProfile;
