
import React from 'react';

function ModuleCoordinatorStaff() {
  return (
    <div>
      <h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1><h1>Module Coordinator Staff</h1>
    </div>
  );
}

export default ModuleCoordinatorStaff;
