 
// AdminUsers.jsx
import React from 'react';

const AdminUsers = () => {
  return (
    <div className="admin-users">
      <h1>Users</h1>
      <p>This section is for managing user accounts.</p>
    </div>
  );
};

export default AdminUsers;
