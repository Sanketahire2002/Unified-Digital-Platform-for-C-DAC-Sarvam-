  
// AdminMeetings.jsx
import React from 'react';

const AdminMeetings = () => {
  return (
    <div className="admin-meetings">
      <h1>Meetings</h1>
      <p>This section is for managing meetings.</p>
    </div>
  );
};

export default AdminMeetings;
